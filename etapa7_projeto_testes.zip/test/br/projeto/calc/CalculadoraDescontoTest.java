package br.projeto.calc;

import org.junit.Test;
import static org.junit.Assert.*;

public class CalculadoraDescontoTest {
    @Test
    public void testAplicarDesconto() {
        CalculadoraDesconto calc = new CalculadoraDesconto();
        double resultado = calc.aplicarDesconto(100.0, 10.0);
        assertEquals(90.0, resultado, 0.01);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValoresInvalidos() {
        CalculadoraDesconto calc = new CalculadoraDesconto();
        calc.aplicarDesconto(-100.0, 10.0);
    }
}
