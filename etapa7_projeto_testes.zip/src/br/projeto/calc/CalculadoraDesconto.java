package br.projeto.calc;

public class CalculadoraDesconto {
    public double aplicarDesconto(double valor, double percentual) {
        if(valor < 0 || percentual < 0){
            throw new IllegalArgumentException("Valores inválidos!");
        }
        return valor - (valor * (percentual / 100));
    }
}
